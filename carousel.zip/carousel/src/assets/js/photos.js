const data = {
  properties: [
    {
      url:
        "http://matthewgoodrich.com/assets/images/clouds-daylight-environment-462146.jpg",
      label: "First slide label",
      title: "Nulla vitae elit libero",
      content: "Nulla vitae elit libero, a pharetra augue mollis interdum."
    },
    {
      url:
        "http://matthewgoodrich.com/assets/images/beach-clouds-dawn-635279.jpg",
      label: "Second slide label",
      title: "consectetur adipiscing elit",
      content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
    },
    {
      url:
        "http://matthewgoodrich.com/assets/images/hd-wallpaper-ocean-sea-37730.jpg",
      label: "Third slide label",
      title: "consectetur adipiscing elit",
      content:
        "Praesent commodo cursus magna, vel scelerisque nisl consectetur."
    }
  ]
};

export default data;
